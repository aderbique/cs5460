[09/27/2017 11:58] seed@ubuntu:~/Desktop/cs5460/assn3/part1$ sudo openssl enc -aes-128-ecb -in simple.bmp -out ENC-aes-128-ecb.bin -K 00112233445566778889aabbccddeeff -iv 0102030405060708
[09/27/2017 11:58] seed@ubuntu:~/Desktop/cs5460/assn3/part1$ sudo openssl enc -aes-128-cbc -in simple.bmp -out ENC-aes-128-ccb.bin -K 00112233445566778889aabbccddeeff -iv 0102030405060708
[09/27/2017 11:59] seed@ubuntu:~/Desktop/cs5460/assn3/part1$ 
