<?php
/**
 * Top page create river view.
 *
 * @package ElggPages
 */

echo elgg_view('river/object/page/create', $vars);