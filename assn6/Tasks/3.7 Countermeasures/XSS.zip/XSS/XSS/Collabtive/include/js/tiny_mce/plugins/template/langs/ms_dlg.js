tinyMCE.addI18n('ms.template_dlg',{
title:"Templet",
label:"Templet",
desc_label:"Huraian",
desc:"Masukkan pra takrifan kandungan templet",
select:"Pilih templet",
preview:"Pratonton",
warning:"Amaran: Memperbaharui template dengan yang lain akan menyebabkan kehilangan data.",
mdate_format:"%Y-%m-%d %H:%M:%S",
cdate_format:"%Y-%m-%d %H:%M:%S",
months_long:"Januari,Febuari,Mac,April,Mei,Jun,Julai,Ogos,September,Oktober,November,Disember",
months_short:"Jan,Feb,Mac,Apr,Mei,Jun,Jul,Ogo,Sep,Okt,Nov,Dis",
day_long:"Ahad,Isnin,Selasa,Rabu,Khamis,Jumaat,Sabtu,Ahad",
day_short:"Aha,Isn,Sel,Rab,Kha,Jum,Sab,Aha"
});